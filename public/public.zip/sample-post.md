---
title: "Post Title"
date: 2019-01-04T13:22:14+24:00
draft: false
type: "post"
tags: ["javascript", "es6", "developers"]
---



![thewebdev](https://res.cloudinary.com/iambeejayayo/image/upload/c_scale,w_100/v1547954566/fav-500.png)