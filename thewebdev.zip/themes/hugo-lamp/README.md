﻿# hugo-lamp

A light responsive [Hugo](https://gohugo.io/) [⚡ AMP](https://www.ampproject.org/) theme for blogger.